<?php 

 <?php
session_start();
$conn=mysqli_connect("localhost","root", "");
mysqli_select_db($conn,"ktour");

//receive form data

$email=$_POST['user_ka_email'];
$password=$_POST['user_ka_password'];

//perform query
$query="SELECT * FROM `message` WHERE `email` LIKE '$email' ";

$result=mysqli_query($conn, $query);

$num_rows=mysqli_num_rows($result);

//respond accodingly
if($num_rows==1)
{
	header("Location: contact.php");
}
else
{
	header('Location: contact.php?msg=1');
}



?>
 ?>