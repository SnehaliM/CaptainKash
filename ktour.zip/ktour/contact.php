<!DOCTYPE html>

<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Contact &mdash; </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<!-- <link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700,900' rel='stylesheet' type='text/css'>
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:300,400,700" rel="stylesheet"> -->
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body class="back">

	<nav id="fh5co-main-nav" role="navigation">
		<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle active"><i></i></a>
		<div class="js-fullheight fh5co-table">
			<div class="fh5co-table-cell js-fullheight">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="gallery.html">Gallery</a></li>
					<li><a href="services.html">Year Plan</a></li>
					<li><a href="about.html">Reviews</a></li>
					<li class="active"><a href="contact.html">Contact</a></li>
				</ul>
			</div>
		</div>
	</nav>
	
	<div id="fh5co-page">
		<header>
			<div class="container">
				<div class="fh5co-navbar-brand">
					<h1 class="text-center"><a class="fh5co-logo" href="index.html"><i class="icon-map-marker"></i></a></h1>
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
				</div>
			</div>
		</header>
		<div id="fh5co-intro-section">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center animate-box">
						<h2 class="intro-heading">Contact Us</h2>
						<p><span>K tours provides the best tour plans. <i class="icon-heart3"></i> We make your tour plans as you please.Feel free to contact us and we will do our best to give you a life-time experience</span></p>
					</div>
				</div>
			</div>
		</div>
		<div id="fh5co-map-section">
			<div class="container animate-box">
				<div id="map" class="fh5co-map animate-box"></div>
				<!-- END map -->
			</div>
		</div>
		<div id="fh5co-contact-section">
			<div class="container">
				<div class="row">
					<div class="col-md-4 animate-box">
						<h3>Our Address</h3>
						<ul class="contact-info">
							<li><i class="icon-location-pin"></i>198 West 21th Street, Park Street.</li>
							<li><i class="icon-phone2"></i>+ 91 12548458</li>
							<li><i class="icon-mail"></i><a href="#">info@ktours.com</a></li>
							<li><i class="icon-globe2"></i><a href="#">www.ktourscompany.com</a></li>
						</ul>
					</div>
					<div class="col-md-8 animate-box">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Name" name="user_name">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Email" name="user_email">
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<textarea name="user_msg" class="form-control" id="" cols="30" rows="7" placeholder="Message"></textarea>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									
								<input type="submit" value="Send Message" class="btn btn-primary" >
								<?php
                if(isset($_GET['msg']))
                {
                    echo "<p style='color:red'>Incorrect Username/password</p>";
                }

                ?>
 
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End: fh5co-contact-section -->
		<footer>
			<div id="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-3">
							<h3 class="section-title">Our Believe</h3>
							<p>Our mission is not just to be a travel agency which helps you book a holiday; we want to be your travel partner who would go an extra mile to help you choose an ideal destination and learn more about the place you have been dreaming to visit. Since holidays are more about personal choices and interests, we bring to you customizable tour packages as well. We give you the prerogative to pick and choose anything that matches your interest. No matter how many travel experiences we sell every day, we ensure that you are the protagonist of your own travel story. 
                           </p>
						</div>
						
						<div class="col-md-3">
							<h3 class="section-title">Our Services</h3>
							<p>To ensure that you have a fulfilled holiday and wholesome experiences, all our holiday services are at your beck and call. On your international holiday, we ensure that you are well-equipped with foreign exchange, visa and travel insurance. We are the pioneers of foreign exchange in India and booking forex online is simple and convenient with us. Our online visa services are one-of-a-kind and make the cumbersome process of booking visa a cake walk for customers. We also provide special visa, forex and travel insurance services for students travelling abroad for study. </p>
						</div>

						<div class="col-md-3">
							<h3 class="section-title"></h3>
							<p>
							Whether it’s booking flights or hotels for your travel, Thomas Cook offers everything under one umbrella. We also have cruise holidays for people who are looking for comfort and affordable luxury. </p>
						</div>


						<div class="col-md-2">
							<h3 class="section-title">Information</h3>
							<ul>
								<li><a href="tc.html">Terms &amp; Condition</a></li>
								<li><a href="tc.html">License</a></li>
								<li><a href="tc.html">Privacy &amp; Policy</a></li>
								<li><a href="contact.html">Contact Us</a></li>
							</ul>
						</div>
					</div>
					<div class="row copy-right">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icon">
								<a href="#"><i class="icon-twitter2"></i></a>
								<a href="#"><i class="icon-facebook2"></i></a>
								<a href="#"><i class="icon-instagram"></i></a>
								<a href="#"><i class="icon-dribbble2"></i></a>
								<a href="#"><i class="icon-youtube"></i></a>
							</p>
							<p>Copyright K Tours <a href="#">Travel with us and get a life time expirience</a>. All Rights Reserved. <br>Made with <i class="icon-heart3"></i> </p>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Google Map -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
	<script src="js/google_map.js"></script>

	<!-- Main JS (Do not remove) -->
	<script src="js/main.js"></script>

	</body>
</html>

